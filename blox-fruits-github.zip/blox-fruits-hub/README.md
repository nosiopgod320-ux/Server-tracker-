# Blox Fruits Hub — Free 24/7 Setup (GitHub)

Everything runs free forever. No credit card. No server to manage.

---

## How it works

- **GitHub Actions** runs the scanner every 15 minutes automatically
- **GitHub Pages** hosts the dashboard website
- Results saved as `data/servers.json` in your repo

---

## Step-by-step setup (10 minutes)

### 1. Create a GitHub account
If you don't have one: https://github.com/signup (free)

### 2. Create a new repo
- Go to https://github.com/new
- Name it anything, e.g. `blox-fruits-hub`
- Set to **Public** (required for free GitHub Pages)
- Click **Create repository**

### 3. Push this code to your repo
In this Replit, open the Shell and run:
```bash
git remote add github https://github.com/YOUR_USERNAME/blox-fruits-hub.git
git push github main
```
Replace `YOUR_USERNAME` with your actual GitHub username.

### 4. Enable GitHub Actions write permission
- Go to your repo on GitHub
- Click **Settings** → **Actions** → **General**
- Scroll to **Workflow permissions**
- Select **Read and write permissions**
- Click **Save**

### 5. Enable GitHub Pages
- Go to **Settings** → **Pages**
- Under **Source**, select **Deploy from a branch**
- Branch: `main`, Folder: `/docs`
- Click **Save**
- Your dashboard URL will be: `https://YOUR_USERNAME.github.io/blox-fruits-hub/`

### 6. Trigger the first scan manually
- Go to **Actions** tab in your repo
- Click **Blox Fruits Server Scanner**
- Click **Run workflow** → **Run workflow**
- Watch it run (takes ~1 minute)

After the first scan, every 15 minutes the scanner runs automatically forever.

---

## Optional: Discord notifications

Get a message in Discord whenever servers are close to an event.

### Set up a Discord webhook:
1. Open Discord → go to any channel
2. Click the gear ⚙️ → **Integrations** → **Webhooks** → **New Webhook**
3. Copy the webhook URL

### Add it to GitHub:
1. Go to repo **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `DISCORD_WEBHOOK`
4. Value: paste the webhook URL
5. Click **Add secret**

The scanner will now post to Discord whenever it finds servers within 10 minutes of an event.

---

## FAQ

**How often does it scan?**
Every 15 minutes, automatically, 24/7, for free.

**What if it gets rate-limited by Roblox?**
It stops early and saves whatever it got. Next scan runs in 15 minutes.

**Will it work forever?**
GitHub gives 2,000 free Action minutes per month. Each scan uses ~30 seconds. 15-min interval = ~96 runs/day × 30 days × 0.5 min = ~1,440 minutes. Under the 2,000 limit.

**Can I check the dashboard on my phone?**
Yes — bookmark `https://YOUR_USERNAME.github.io/blox-fruits-hub/` on your phone.
