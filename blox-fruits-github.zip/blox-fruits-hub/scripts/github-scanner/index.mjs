/**
 * Blox Fruits Server Scanner — GitHub Actions edition
 * Runs every 15 minutes, reads/writes data/ folder, commits results.
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT      = join(__dirname, "..", "..");
const DATA_DIR  = join(ROOT, "data");
const STATE_FILE   = join(DATA_DIR, "state.json");
const SERVERS_FILE = join(DATA_DIR, "servers.json");

const PLACE_ID = 2753915549; // Sea1
// Pirate/Castle Raid: Sea 3 only — first at 1h 15m (4500s) after server start, repeats every 60 min
// Factory Raid:       Sea 2+3  — first at 15 min (900s) after server start, repeats every 2 hr
// Fruit Spawn:        All seas — repeats every 60 min weekdays / 45 min weekends (no fixed first-event offset)
const EVENTS = {
  PirateRaid:  { offset: 4500, interval: 3600 },
  FactoryRaid: { offset: 900,  interval: 7200 },
  FruitSpawn:  { offset: 0,    interval: () => {
    const day = new Date().getUTCDay(); // 0=Sun, 6=Sat
    return (day === 0 || day === 6) ? 2700 : 3600;
  }},
};
const MAX_PAGES      = 3;   // 3 pages = 300 servers, safe from 429
const PAGE_DELAY_MS  = 3000;
const TOP_N          = 10;  // top servers per event in output

// ─── State helpers ───────────────────────────────────────────────────────────

function loadState() {
  if (!existsSync(STATE_FILE)) {
    return { isFirstScan: true, servers: {}, lastScanAt: null };
  }
  return JSON.parse(readFileSync(STATE_FILE, "utf8"));
}

function saveState(state) {
  mkdirSync(DATA_DIR, { recursive: true });
  writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

function saveServers(data) {
  mkdirSync(DATA_DIR, { recursive: true });
  writeFileSync(SERVERS_FILE, JSON.stringify(data, null, 2));
}

// ─── Roblox API ──────────────────────────────────────────────────────────────

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function fetchPage(cursor, pageNum) {
  let url = `https://games.roblox.com/v1/games/${PLACE_ID}/servers/Public?limit=100`;
  if (cursor) url += `&cursor=${encodeURIComponent(cursor)}`;

  console.log(`  Fetching page ${pageNum}…`);

  const res = await fetch(url, {
    headers: {
      "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "Accept":          "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9",
      "Referer":         `https://www.roblox.com/games/${PLACE_ID}/`,
    },
    signal: AbortSignal.timeout(15_000),
  });

  if (res.status === 429) {
    console.log(`  Rate limited on page ${pageNum} — stopping early`);
    return { servers: [], nextCursor: null, rateLimited: true };
  }

  if (!res.ok) throw new Error(`Roblox API ${res.status}`);

  const data = await res.json();
  const servers = data.data ?? [];
  console.log(`  Page ${pageNum}: ${servers.length} servers`);
  return { servers, nextCursor: data.nextPageCursor ?? null, rateLimited: false };
}

async function fetchAllServers() {
  const all = [];
  let cursor = null;
  let pages  = 0;

  while (pages < MAX_PAGES) {
    const { servers, nextCursor, rateLimited } = await fetchPage(cursor, pages + 1);
    all.push(...servers);
    pages++;
    if (rateLimited || !nextCursor) break;
    await sleep(PAGE_DELAY_MS);
    cursor = nextCursor;
  }

  return all;
}

// ─── Event math ──────────────────────────────────────────────────────────────

function buildEventResults(state, nowSec) {
  const results = {};

  for (const [event, cfg] of Object.entries(EVENTS)) {
    const interval = typeof cfg.interval === "function" ? cfg.interval() : cfg.interval;
    const offset   = cfg.offset;
    const servers  = [];

    for (const [jobId, entry] of Object.entries(state.servers)) {
      if (entry.status !== "tracked" || entry.firstSeen == null) continue;
      if ((entry.fps ?? 60) < 20) continue;

      const age = nowSec - entry.firstSeen;
      // Before the first event fires → count down to offset
      // After → count down within the repeating cycle
      const timeUntilEvent = age < offset
        ? Math.round(offset - age)
        : Math.round(interval - ((age - offset) % interval));

      servers.push({
        jobId,
        timeUntilEvent,
        estimatedAge: Math.round(age),
        playing:      entry.playing ?? 0,
        fps:          Math.round((entry.fps ?? 60) * 10) / 10,
      });
    }

    servers.sort((a, b) => a.timeUntilEvent - b.timeUntilEvent);
    results[event] = servers.slice(0, TOP_N);
  }

  return results;
}

// ─── Main ────────────────────────────────────────────────────────────────────

async function main() {
  console.log("=== Blox Fruits Scanner (GitHub Actions) ===");
  console.log(`Time: ${new Date().toISOString()}`);

  const state = loadState();
  const isFirst = state.isFirstScan;

  // KEY FIX: flip at start so partial scans still enable new-server detection
  state.isFirstScan = false;

  if (isFirst) {
    console.log("First scan — building baseline (all servers marked unknown age)");
  } else {
    console.log(`Scanning for new servers (baseline has ${Object.keys(state.servers).length} known)`);
  }

  console.log("Fetching Roblox server list…");
  let liveServers;
  try {
    liveServers = await fetchAllServers();
  } catch (err) {
    console.error("Fetch failed:", err.message);
    process.exit(1);
  }

  console.log(`Total fetched: ${liveServers.length} servers`);

  const nowSec    = Date.now() / 1000;
  const nowIso    = new Date().toISOString();
  const seenIds   = new Set();
  let newCount    = 0;
  let diedCount   = 0;

  for (const s of liveServers) {
    seenIds.add(s.id);
    const existing = state.servers[s.id];

    if (existing) {
      existing.playing = s.playing;
      existing.fps     = s.fps;
    } else if (isFirst) {
      state.servers[s.id] = {
        firstSeen:   null,
        firstSeenTs: null,
        status:      "unknown",
        playing:     s.playing,
        fps:         s.fps,
      };
    } else {
      state.servers[s.id] = {
        firstSeen:   nowSec,
        firstSeenTs: nowIso,
        status:      "tracked",
        playing:     s.playing,
        fps:         s.fps,
      };
      newCount++;
    }
  }

  // Remove closed servers (only when not rate-limited / full scan)
  if (liveServers.length >= 250) {
    for (const jobId of Object.keys(state.servers)) {
      if (!seenIds.has(jobId)) {
        delete state.servers[jobId];
        diedCount++;
      }
    }
  }

  state.lastScanAt = nowIso;

  const totalKnown   = Object.keys(state.servers).length;
  const totalTracked = Object.values(state.servers).filter(e => e.status === "tracked").length;
  const totalUnknown = totalKnown - totalTracked;

  console.log(`New: +${newCount} | Closed: -${diedCount} | Tracked: ${totalTracked} | Unknown age: ${totalUnknown}`);

  // Build public output
  const eventResults = buildEventResults(state, nowSec);
  const publicData = {
    updatedAt:    nowIso,
    totalKnown,
    totalTracked,
    totalUnknown,
    isFirstScan:  false,
    newThisScan:  newCount,
    events:       eventResults,
  };

  // Discord webhook notification (optional — set DISCORD_WEBHOOK secret in GitHub)
  const webhookUrl = process.env.DISCORD_WEBHOOK;
  if (webhookUrl && !isFirst && newCount > 0) {
    const lines = [`**Blox Fruits Scanner** — ${new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })} UTC`];
    lines.push(`📡 Tracked: **${totalTracked}** servers | +${newCount} new this scan`);
    lines.push("");

    for (const [event, servers] of Object.entries(eventResults)) {
      const soon = servers.filter(s => s.timeUntilEvent < 600);
      if (soon.length === 0) continue;
      const label = { PirateRaid: "⚔️ Pirate/Castle Raid (Sea 3)", FactoryRaid: "🏭 Factory Raid (Sea 2+3)", FruitSpawn: "🍎 Fruit Spawn (All seas)" }[event] ?? event;
      lines.push(`${label} — servers within 10 min:`);
      for (const s of soon.slice(0, 3)) {
        const min = Math.floor(s.timeUntilEvent / 60);
        const sec = s.timeUntilEvent % 60;
        lines.push(`\`${s.jobId}\` — **${min}m ${sec}s** | ${s.playing} players`);
      }
      lines.push("");
    }

    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: lines.join("\n").slice(0, 2000) }),
      });
      console.log("Discord webhook sent");
    } catch (e) {
      console.warn("Discord webhook failed:", e.message);
    }
  }

  saveState(state);
  saveServers(publicData);

  console.log("State and servers.json saved ✓");
  console.log("Done.");
}

main().catch(err => {
  console.error("Fatal:", err);
  process.exit(1);
});
